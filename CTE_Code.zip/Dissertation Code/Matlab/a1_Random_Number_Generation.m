%%Random Number Generation

%vsim = random('norm',0,1,C,S,T,N);
vsim1 = random('norm',0,1,5,5,13,16197);
%Simulations for the emax function
%elsim = random('norm',0,1,C,E,T,N);
esim1 = random('norm',0,1,5,5,22,16197);

vsimneg = -vsim1;
esimneg = -esim1;

vsim = zeros(5,10,13,16197);
esim = zeros(5,10,22,16197);

vsim(:,1:5,:,:)= vsim1;
vsim(:,6:10,:,:)= vsimneg;

esim(:,1:5,:,:)= esim1;
esim(:,6:10,:,:)= esimneg;

clear vsim1 esim1 vsimneg esimneg


%Sim choice path random numbers
norsim1 = random('norm',0,1,5,5,13,16197);

norsimneg = -norsim1;
norsim = zeros(5,10,13,16197);

norsim(:,1:5,:,:)= norsim1;
norsim(:,6:10,:,:)= norsimneg;

clear norsim1 norsimneg



wexpsim = zeros(13,10,16197);
evsim = zeros(15,10,13,16197);

wexpsim1 = zeros(13,5,16197);
evsim1 = zeros(15,5,13,16197);

 for i = 1:16197;
     for s = 1:5;
        for j = 1:13;         
        wexpsim1(j,s,i) = unifrnd(0,1);
         end
     end
 end
 
 
 for i = 1:16197; 
     for k = 1:13;       
         for s = 1:5;
             for h = 1:15;
             evsim1(h,s,k,i) = evrnd(0,1);
             end
         end
     end
 end 
 
 
wexpsimneg = 1-wexpsim1;
evsimneg = -evsim1;
 
wexpsim(:,1:5,:)= wexpsim1;
wexpsim(:,6:10,:)= wexpsimneg;

evsim(:,1:5,:,:)= evsim1;
evsim(:,6:10,:,:)= evsimneg; 


clear wexpsim1 evsim1 wexpsimneg evsimneg
clear h i j k s

esim = single(esim);
vsim = single(vsim);
evsim = single(evsim);
norsim = single(norsim);
wexpsim = single(wexpsim);
     