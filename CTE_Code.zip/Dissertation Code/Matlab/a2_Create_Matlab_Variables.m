%This code organizes the Stata data into matlab matrices

%Start by Importing Stata data and random number data


%% %----UNIVERSAL VARIABLES----%

% %Number of individuals
 N = 16197;

% 
% %Number of time periods
 T = 13;
 %Tstar is the final period when you have a choice (when you're 35)
 Tstar = 22;
 %Tdubstar is the period you die/retire (when you're 65)
 Tdubstar = 30;
% 
% %Number of choices
C = 15;
%     %choice 1 = school 1
%     %choice 2 = school 2
%     %choice 3 = school 3
%     %choice 4 = school 4
%     %choice 5 = school 5
%     %choice 6 = work 1
%     %choice 7 = work 2
%     %Choice 8 = work 3
%     %choice 9 = work 4
%     %choice 10 = work 5
%     %choice 11 = unemployed
%     %choice 12 = trade school
%     %choice 13 = community college
%     %choice 14 = university
      %choice 15 = GED

%     
% %Number of observable characteristics (variables)
V = 70;

% Wage
%     %parameter 1 = HS grad academic
%     %parameter 2 = HS grad gen ed
%     %parameter 3 = HS grad bus voc
%     %parameter 4 = HS grad trade
%     %parameter 5 = HS grad othervoc
      %parameter 6 = HS grad GED
    

%     %parameter 7 = trade school grad
%     %parameter 8 = community college grad
%     %parameter 9 = university grad
     
%     %parameter 10 = sex - male (wage)
%     %parameter 11 = race1 - black (wage)
      %parameter 12 = race2 - hispanic (wage)
      %parameter 13 = race3 - other (wage)
      %parameter 14 = ses  (wage)
      %parameter 15 = testscore (wage)
      %parameter 16 = region1 - midwest (wage)
      %parameter 17 = region2 - south (wage)
      %parameter 18 = region3 - west (wage)
      %parameter 19 = urban1 - suburban (wage)
      %parameter 20 = urban2 - rural (wage)
      %parameter 21 = catholic (wage)
      %parameter 22 = private (wage)
      
      %parameter 23 = rate, unemployment  (wage)
      %parameter 24 = lnavwage (wage)
      %parameter 25 = percent empprof  (wage)
      %parameter 26 = percent empskillman (wage)
      %parameter 27 = percent empskillnonman  (wage)

      %parameter 28 = constant (wage)
      
% Utility

%     %parameter 29 = sex (utility)
%     %parameter 30 = race1 - black (utility)
      %parameter 31 = race2 - hispanic (utility)
      %parameter 32 = race3 - other (utility)
      %parameter 33 = ses  (utility)
      %parameter 34 = testscore (utility)
      %parameter 35 = region1 - midwest (utility)
      %parameter 36 = region2 - south (utility)
      %parameter 37 = region3 - west (utility)
      %parameter 38 = urban1 - suburban (utility)
      %parameter 39 = urban2 - rural (utility)
      %parameter 40 = catholic (utility)
      %parameter 41 = private (utility)
       
      %parameter 42 = rate, unemployment (work utility)
      %parameter 43 = avwage (work utility)
      %parameter 44 = percent empprof  (work utility)
      %parameter 45 = percent empskillman (work utility)
      %parameter 46 = percent empskillnonman  (work utility)
       
      %parameter 47 = marketing HS (HS utility)
      %parameter 48 = marketing area (HS utility)
      %parameter 49 = precisions HS (HS utility)
      %parameter 50 = precisions area (HS utility)
      
      %parameter 51 = percent academic (HS utility)
      
      %parameter 52 = voc HS (HS utility)
      %parameter 53 = voc Area (HS utility)
      %parameter 54 = voc both (HS utility)
      %parameter 55 = students per voc teach (HS utility)
      %parameter 56 = no voc teachers (HS utility)
      %parameter 57 = career pathways (HS utility)
      %parameter 58 = percent voc (HS utility)
      
      %parameter 59 = %Free lunch (HS utility)
      %parameter 60 = admission area (HS utility)      
      %parameter 61 = student influence (HS utility)
      %parameter 62 = missing1 (HS utility)
               
      %parameter 63 = percent labor market (HS utility & PSE utility)
      %parameter 64 = percent 2 yr (HS utility & PSE utility)      
      %parameter 65 = percent 4 yr (HS utility & PSE utility)
      %parameter 66 = missing2 (HS utility & PSE utility)
            
      %parameter 67 = percent college fairs (PSE utility)     
      %parameter 68 = percent college ap program (PSE utility)
      
      %parameter 69 = constant (utility)
      
      %parameter 70 = GED offered at school (utility)



% %create a variable for the variance of the errors
 W=1;
% 
 
%Future discount rate
 B = 0.95;
% 
%% ---- CREATE DATA FOR MONTE CARLO ESTIMATION ---- %%
% 

% 
wob = 1;




    %Create initial conditions for years of school: e is 0, 1, or 2
     X = zeros(V,T,N);
     PSX = zeros(8,T,N);
    %X(1,1,:)=X(6,1,:)=X(7,1,:)=X(8,1,:)=X(9,1,:)=0

    
    %Create initial conditions for the constant: the value is 1 for every individual at every time
    X(28,:,:) = 1;
    X(69,:,:) = 1;
    

    
    
        %Create initial conditions for Gender: G is 0 (female) or 1 (male) with equal probability
%The values for gender are the same through all periods
for i = 1:N;
       if male(i) == 1; 
        X(10,:,i) = 1;  
        X(29,:,i) = 1;
       end
end
  


 
    %Create initial conditions for Race (see above for labels)
      %The values for gender are the same through all periods
for i = 1:N;
       if black(i) == 1; 
        X(11,:,i) = 1;  
        X(30,:,i) = 1;
       end
       if hispanic(i) == 1; 
        X(12,:,i) = 1;  
        X(31,:,i) = 1;
       end
       if other_race(i) == 1; 
        X(13,:,i) = 1;  
        X(32,:,i) = 1;
       end
end




%Create initial conditions for Family socioeconomic status: a continuous variable from 0 to 5
 for i = 1:N; 
         X(14,:,i) = ses(i);  
         X(33,:,i) = ses(i);
 end
% 
% %Create initial conditions for test score: ln test score is a countinuous variable from 0 to 4
% lntestscore = log(TESTSCORE);
 for i = 1:N; 
         X(15,:,i) = testscore(i);  
         X(34,:,i) = testscore(i);
 end

%Create initial conditions for parents income (quantile): a discrete variable from 0 to 4
%I subtract one becuase the variable goes from 1-5 initially, and I want it to go from 0-4
% for i = 1:N; 
%         X(11,:,i) = PARENTSINCOME(i) - 1;  
%         X(24,:,i) = PARENTSINCOME(i) - 1;
% end
% 
% %Create initial conditions number of parents
% %Create dummy variables for no parents and one parent, respectively
% for i = 1:N;
%        if PARENTS(i) == 0; 
%         X(12,:,i) = 1;  
%         X(25,:,i) = 1;
%        end
%        
%        if PARENTS(i) == 1; 
%         X(13,:,i) = 1;  
%         X(26,:,i) = 1;
%        end     
% end

% %Create initial conditions for region
% %Create dummy variables for northcentral, south, and west, respectively
for i = 1:N;
       if midwest(i) == 1; 
        X(16,:,i) = 1;  
        X(35,:,i) = 1;
       end
       
       if south(i) == 1; 
        X(17,:,i) = 1;  
        X(36,:,i) = 1;
       end    
       
       if west(i) == 1; 
        X(18,:,i) = 1;  
        X(37,:,i) = 1;
       end   
end


%Create initial conditions for urbanicity
%Create dummy variables for suburban and rural, respectively
for i = 1:N;
       if suburban(i) == 1; 
        X(19,:,i) = 1;  
        X(38,:,i) = 1;
       end
       
       if rural(i) == 1; 
        X(20,:,i) = 1;  
        X(39,:,i) = 1;
       end     
end


%Create initial conditions for school control
for i = 1:N;
       if catholic(i) == 1; 
        X(21,:,i) = 1;  
        X(40,:,i) = 1;
       end
      
       if private(i) == 1; 
        X(22,:,i) = 1;  
        X(41,:,i) = 1;
       end     
end



%    
%    
% for i = 1:N;
%        if OFBUSVOC(i) == 1; 
%         X(45,:,i) = 1;  
%        end
%        if OFTRADEVOC(i) == 1; 
%         X(46,:,i) = 1;  
%        end
%        if OFOTHERVOC(i) == 1; 
%         X(47,:,i) = 1;  
%        end   
%        if VOCCOUNCELING(i) == 1; 
%         X(48,:,i) = 1;  
%        end
%        if FULLTIMEVOCTEACH(i) == 1; 
%         X(49,:,i) = 1;  
%        end
%        if WORKSTUDYPROGAVAIL(i) == 1; 
%         X(50,:,i) = 1;  
%        end
%        if JOBFAIRSAVAIL(i) == 1; 
%         X(51,:,i) = 1;  
%        end
% end   


%Create values for local labor market characteristics
 for i = 1:N; 
         X(23,:,i) = rate(i);  
         X(42,:,i) = rate(i);
         X(24,:,i) = lnavincome(i);  
         X(43,:,i) = lnavincome(i);
         X(25,:,i) = profemppercent(i);  
         X(44,:,i) = profemppercent(i);
         X(26,:,i) = manemppercent(i);  
         X(45,:,i) = manemppercent(i);
         X(27,:,i) = nonmanemppercent(i);  
         X(46,:,i) = nonmanemppercent(i);
 end


 %create initial conditions for the other instruments
  for i = 1:N; 
         X(47,:,i) = marketingHS(i);  
         X(48,:,i) = marketingarea(i); 
         X(49,:,i) = precisionsHS(i);
         X(50,:,i) = precisionsarea(i);  
     
         X(51,:,i) = perac(i);
         
         X(52,:,i) = vocHS(i);  
         X(53,:,i) = vocarea(i);
         X(54,:,i) = vocboth(i);  
         X(55,:,i) = STUDPERVOCTEACH(i);  
         X(56,:,i) = novocteachers(i);  
         X(57,:,i) = careerpathways(i);
         X(58,:,i) = pervoc(i);
         
         X(59,:,i) = FREELUNCH(i); 
         X(60,:,i) = admissionarea(i); 
         X(61,:,i) = stuinfl(i);  
 
         X(63,:,i) = perlabor(i);  
         X(64,:,i) = per2yr(i); 
         X(65,:,i) = per4yr(i);
         
         X(67,:,i) = percolfairs(i);
         X(68,:,i) = percolapprog(i);
         
         X(70,:,i) = GEDoffered(i);
  end

  %Create two aggregate variables for missing
for i = 1:N;
    if marketingmissing(i) == 1 | precisionsmissing(i) == 1 | peracmissing(i) == 1 | voclocmissing(i) == 1 | studpervocteachmissing(i) == 1 | careerpathwaysmissing(i) == 1 | pervocmissing(i)  == 1 | FREELUNCHmissing(i) == 1 | admissionareamissing(i) == 1 | stuinflMISSING(i) == 1;
        X(62,:,i) = 1;
    end
    if perlabormissing(i) == 1 | per2yrmissing(i) == 1 | per4yrmissing(i) == 1 | percolfairsmissing(i) == 1 | percolapprogmissing(i) == 1 | GEDofferedmissing(i) == 1
        X(66,:,i) = 1;
    end
end


%Add a variable for if I know you never finished your education
nvattain = zeros(4,N);
for i = 1:N;   
    %Individuals who never finished HS never finished PSE either
  %if HSoutcome(i) == 0;
  %  myPSEattain(i) = 0;
  %end
    
    %Create nvattain variable
    if EDUattainment(i) == 0;
        nvattain(1,i) = 1;
        nvattain(4,i) = 1;
        nvattain(3,i) = 1;
        nvattain(2,i) = 1;
    end
    if EDUattainment(i) >= 1 & EDUattainment(i) <= 2;
        nvattain(4,i) = 1;
        nvattain(3,i) = 1;
        nvattain(2,i) = 1;
    end
    if EDUattainment(i) == 3;
        nvattain(4,i) = 1;
        nvattain(3,i) = 1;
    end
    if EDUattainment(i) == 4;
        nvattain(4,i) = 1;
    end
end
    




%%  ----POPULATE Y* and Wob ------%% 
%     
 ystar = zeros(N,T);

 
%Correctly code job type in high school
% for i = 1:N;
%     if OCCUP91(i) == 9;
%         OCCUP91(i) = 11;
%     end
%     if OCCUP91(i) == 8;
%         OCCUP91(i) = 10;
%     end
%     if OCCUP91(i) == 7;
%         OCCUP91(i) = -1;
%     end
%     if OCCUP91(i) == 4;
%         OCCUP91(i) = 9;
%     end
%     if OCCUP91(i) == 3;
%         OCCUP91(i) = 8;
%     end
%     if OCCUP91(i) == 2;
%         OCCUP91(i) = 7;
%     end
% end


%Create a matrix for choice each period
% for i = 1:N;
%     if choice03 == 1;
%         ystar(i,1) = CURR(i);
%     end
%     if HSGRAD(i) == 0;
%         ystar(i,1) = OCCUP91(i);
%     end
% end

ystar(:,1) = choice00;
ystar(:,2) = choice01;
ystar(:,3) = choice02;
ystar(:,4) = choice03;
ystar(:,5) = choice04;
ystar(:,6) = choice05;
ystar(:,7) = choice06;
ystar(:,8) = choice07;
ystar(:,9) = choice08;
ystar(:,10) = choice09;
ystar(:,11) = choice10;
ystar(:,12) = choice11;
ystar(:,13) = choice12;


%Replace "unknown school" with gen ed HS
% for i = 1:N;
%     for j=1:T;
%         if ystar(i,j) == 18;
%           ystar(i,j) = 2;
%         end;
%     end;
% end;

%Replace "masters+ with "unknown"
for i = 1:N;
    for j=1:T;
        if ystar(i,j) == 21;
          ystar(i,j) = 0;
        end;
    end;
end;


%Ignore "unknown college" and "unknown work".  I'm treating both as missing here

% for i = 1:N;
%     for j=1:T;
%         if ystar(i,j) >= 12;
%           ystar(i,j) = -1;
%         end;
%     end;
% end;


%Populate w (consider all wages of 0 as missing as well)
w = zeros(N,T);
for i = 1:N; 
        w(i,1) = lnwage00(i);
        w(i,2) = lnwage01(i);
        w(i,3) = lnwage02(i);
        w(i,4) = lnwage03(i);
        w(i,5) = lnwage04(i);
        w(i,6) = lnwage05(i);
        w(i,7) = lnwage06(i);
        w(i,8) = lnwage07(i);
        w(i,9) = lnwage08(i);
        w(i,10) = lnwage09(i);
        w(i,11) = lnwage10(i);
        w(i,12) = lnwage11(i);
        w(i,13) = lnwage12(i);
end
        
%Take the ln of wages
% for i = 1:N;
%     for j = 1:T;
%         if w(i,j) > 1;
%             w(i,j) = log(w(i,j));
%         end
%     end
% end

   
 %Create information for years of each type of HS curricula
 Y = zeros(5,T,N);
 %Add initial conditions for students who were ahead in 00
 for i = 1:N;
    Y(2,1,i) = initialschooling(i);
 end


        %Next, update the state space vector Y for period 2
for i = 1:N;
    for k = 1:T;       
        Y(:,k+1,i) = Y(:,k,i);

            if ystar(i,k) == 1;
                Y(1,k+1,i) = Y(1,k,i) + 1;
            end
            if ystar(i,k) == 2;
                Y(2,k+1,i) = Y(2,k,i) + 1;
            end
            if ystar(i,k) == 3;
                Y(3,k+1,i) = Y(3,k,i) + 1;
            end
            if ystar(i,k) == 4;
                Y(4,k+1,i) = Y(4,k,i) + 1;
            end
            if ystar(i,k) == 5;
                Y(5,k+1,i) = Y(5,k,i) + 1;
            end
     end
end


        %Finally, update the state space vector X for period 2
for i = 1:N;
    for k = 1:T;       
        X(:,k+1,i) = X(:,k,i);

        %If you graduated from high school this year
        if Y(1,k+1,i) + Y(2,k+1,i) + Y(3,k+1,i) + Y(4,k+1,i) + Y(5,k+1,i) == 4
            if Y(1,k,i) + Y(2,k,i) + Y(3,k,i) + Y(4,k,i) + Y(5,k,i) == 3
                 
                %Trade voc no matter what
                   if Y(4,k,i) >= 2 && Y(3,k,i) == 0;
                        X(4,k+1,i) = X(4,k,i) + 1;
                   end

                %bus voc no matter what
                   if Y(3,k,i) >= 2 && Y(4,k,i) == 0;
                       X(3,k+1,i) = X(3,k,i) + 1;
                   end
                   
                %other voc no matter what
                   if Y(5,k,i) >= 2 && Y(4,k,i) == 0 && Y(3,k,i) == 0;
                       X(5,k+1,i) = X(5,k,i) + 1;
                   end
                   
                %Trade voc unless bus voc
                   if Y(4,k,i) >= 2 && Y(3,k,i) == 1;
                        if ystar(i,k) ~= 3;
                            X(4,k+1,i) = X(4,k,i) + 1;
                        end
                        if ystar(i,k) == 3;
                            X(3,k+1,i) = X(3,k,i) + 1;  
                        end
                   end
                  
                %Bus voc unless trade voc
                   if Y(3,k,i) >= 2 && Y(4,k,i) == 1;
                        if ystar(i,k) ~= 4;
                            X(3,k+1,i) = X(3,k,i) + 1;
                        end
                        if ystar(i,k) == 4;
                            X(4,k+1,i) = X(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless trade voc
                   if Y(5,k,i) >= 2 && Y(4,k,i) == 1;
                        if ystar(i,k) ~= 4;
                            X(5,k+1,i) = X(5,k,i) + 1;
                        end
                        if ystar(i,k) == 4;
                            X(4,k+1,i) = X(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless bus voc
                   if Y(5,k,i) >= 2 && Y(3,k,i) == 1;
                        if ystar(i,k) ~= 3;
                            X(5,k+1,i) = X(5,k,i) + 1;
                        end
                        if ystar(i,k) == 3;
                            X(3,k+1,i) = X(3,k,i) + 1;  
                        end
                   end
                           
                %No more then one year of any voc/academic curricula (curicula is whatever you choose senior year)                                                            
                   if Y(3,k,i) <= 1 && Y(4,k,i) <=1 && Y(5,k,i) <= 1 && Y(1,k,i) <=1;
                        if ystar(i,k) == 1;
                            X(1,k+1,i) = X(1,k,i) + 1;
                        end
                        if ystar(i,k) == 2;
                            X(2,k+1,i) = X(2,k,i) + 1;
                        end
                        if ystar(i,k) == 3;
                            X(3,k+1,i) = X(3,k,i) + 1;
                        end
                        if ystar(i,k) == 4;
                            X(4,k+1,i) = X(4,k,i) + 1;
                        end
                        if ystar(i,k) == 5;
                            X(5,k+1,i) = X(5,k,i) + 1;
                        end
                   end
                                              
                 %Academic equal to 2 and all voc equal to 0 or 1 (implied)
                   if Y(1,k,i) == 2;
                        if ystar(i,k) >= 1 && ystar(i,k) <=2;
                            X(1,k+1,i) = X(1,k,i) + 1;
                        end
                        if ystar(i,k) == 3;
                            X(3,k+1,i) = X(3,k,i) + 1;
                        end
                        if ystar(i,k) == 4;
                            X(4,k+1,i) = X(4,k,i) + 1;
                        end
                        if ystar(i,k) == 5;
                            X(5,k+1,i) = X(5,k,i) + 1;
                        end
                   end
                   
                  %Academic equal to 3 (academic no matter what)
                   if Y(1,k,i) == 3;
                        X(1,k+1,i) = X(1,k,i) + 1;
                   end
                                          
            end
        end
        
        %GED completion
        if ystar(i,k) == 15
           X(6,k+1,i) = X(6,k,i) + 1; 
        end
        
     end
end 


%Create information for years of each type of college graduation
 Z = zeros(3,T,N);

        %Next, update the state space vector Y for period 2
for i = 1:N;
    for k = 1:T; 
        Z(:,k+1,i) = Z(:,k,i);

            if ystar(i,k) == 12;
                Z(1,k+1,i) = Z(1,k,i) + 1;
            end
            if ystar(i,k) == 13;
                Z(2,k+1,i) = Z(2,k,i) + 1;
            end
            if ystar(i,k) == 14;
                Z(3,k+1,i) = Z(3,k,i) + 1;
            end
     end
end

        %Finally, update the state space vector X for period 2
for i = 1:N;
    for k = 1:T;       
        X(7:9,k+1,i) = X(7:9,k,i);
        %PSX(6:8,k+1,i) = PSX(6:8,k,i);
        
        %If you graduated from trade school this year
        if ystar(i,k) == 12;
             X(7,k+1,i) = X(7,k,i) + 1;
             %PSX(6,k+1,i) = PSX(6,k,i) + 1;
        end
             
        %If you graduated from community college this year
        if Z(2,k,i) == 1;
            if Z(2,k+1,i) == 2;
                 X(8,k+1,i) = X(8,k,i) + 1;
                 %PSX(7,k+1,i) = PSX(7,k,i) + 1;
            end
        end
                
        %If you graduated from university this year
        if Z(3,k,i) == 3;
            if Z(3,k+1,i) == 4;
                 X(9,k+1,i) = X(9,k,i) + 1;
                 %PSX(8,k+1,i) = PSX(8,k,i) + 1;
                                          
            end
        end
        
     end
end 

%Finally, create a variable for the number of years of each type of work you have taken
%Everyone starts with 0 years work experience
WW = zeros(5,T,N);
%Add up the number of years they have worked in each period
for i = 1:N;
    for k = 1:T;
        WW(:,k+1,i) = WW(:,k,i);
        %If you worked in each type of field
        if ystar(i,k)  == 6;
        WW(1,k+1,i) = WW(1,k,i) + 1;
        end
        if ystar(i,k)  == 7;
        WW(2,k+1,i) = WW(1,k,i) + 1;
        end
        if ystar(i,k)  == 8;
        WW(3,k+1,i) = WW(1,k,i) + 1;
        end
        if ystar(i,k)  == 9;
        WW(4,k+1,i) = WW(1,k,i) + 1;
        end
        if ystar(i,k)  == 10;
        WW(5,k+1,i) = WW(1,k,i) + 1;
        end
    end
end




%----DATA SET CREATION COMPLETE-----%



