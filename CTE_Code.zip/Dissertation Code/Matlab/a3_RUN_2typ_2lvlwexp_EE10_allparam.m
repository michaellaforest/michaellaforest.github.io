%This file runs the outer loop. It calls the fortran files which calculate 
%the likelihood function and the likelihood function derivatives for each paramter.
%It then selects new paramter estimates using the BHHH optimization algorithm.



%   esim = permute(esim,[4,1,3,2]);
%   vsim = permute(vsim,[4,1,3,2]);
%   evsim = permute(evsim,[4,1,3,2]);

%force individuals to attend school for their first and second years
% for i = 1:16197;
%     for j = 1:2;
%        if ystar(i,j) == 0 | ystar(i,j) >= 6;
%            ystar(i,j) = 18;
%        end
%     end
% end


X = double(X);
Y = double(Y);
Z = double(Z);
P = double(P);
ystar = double(ystar);
w = double(w);
esim = double(esim);
W = double(W);
B = double(B);
WW = double(WW);
XP = double(XP);
OP = double(OP);
NP = double(NP);
HP = double(HP);
evsim = double(evsim);
wexpsim  = double(wexpsim);
norsim = double(norsim);
nvattain = double(nvattain);

%R = 1;
% 
%     HP = zeros(15,6);
%     HPnew = HP;
% % % % 
%     OP = [OP;1];
%    OP(9) = .3;
%    OPnew = OP;
% % % % % tic
% % % % % %Parallelized version
% % %% 
% % % %  OP = [OP;1]
% % % %  OPnew = OP
% % % % % tic
% % 
% OP(1:5) = 0;
% %OPnew = OP
% %NP(6:10,3:5) = 0;
% %XP(6:10,1:4) = 0;
% % % % %Parallelized version
 VHS = 137;
 VW  = 347;
 va = 13;
 vb = 97;
  vc = 41;
 vd = 7;
% % 
% % % 
% % % 
% % % 
% % % 
% % % % %Length of the vector of parameters to estimate. The parameters for the final choice are set to zero for multicoliniarity
% % % %(job parameters)*(job choices) + (school parameters)*(school choices) +(college parameters)*(college choices)
% % % %QQ = 5*vw+vh*5+vc*3+20;
% % 
% %  Tstar = 22;
% % % 
% % % % % %Lenght of parameters in the P matrix
% % % % % %Q = 5*vw+vh*5+vc*3;
% % % %   Q = 414;
 Q1 = 422;
 Q2 = 445;
 Q3 = 449;
 Q4 = 468;
 QQ = 472;
        QQN = 479; 
        QQP = 479;
   Pvect = zeros(QQP,1);
   Pvectnew = zeros(QQP,1);
   PIter = zeros(QQP,R);
   %G = zeros(N,QQP);
   % 
indLL = zeros(N,1); 
indLL1 = zeros(N,1);
indwageLL1 = zeros(N,1);
indLLutil1 = zeros(N,1);
wageLL1  = zeros(N,T);
indLLchoice1 = zeros(N,T);
emax21 = zeros(Tstar,1);
dindLL = zeros(N,QQ);
dwageLL = zeros(N,QQ);
dutilLL = zeros(N,QQ);
LLnc041 = zeros(N,T);
LLhs001 = zeros(N,T);
demax2 = zeros(Tstar,QQ);



indLL2 = zeros(N,1);
indwageLL2 = zeros(N,1);
indLLutil2 = zeros(N,1);
wageLL2  = zeros(N,T);
indLLchoice2 = zeros(N,T);
emax22 = zeros(Tstar,1);
dindLL2 = zeros(N,QQ);
dwageLL2 = zeros(N,QQ);
dutilLL2 = zeros(N,QQ);
LLnc042 = zeros(N,T);
LLhs002 = zeros(N,T);
demax22 = zeros(Tstar,QQ);

dindLLpar = zeros(N,QQ,2);
indLLpar = zeros(N,1,2);
wageLLpar = zeros(N,T,2);
indLLchoicepar = zeros(N,T,2);

% Diter = zeros(QQ,QQ,20);
% 
% NP = zeros(14,5);
% % % %Preset value guesses for unobserved het
%        NP(1:5,1) = -.5;
%        NP(6:10,1) = .5;
% % % % % % %  NP(11,1) = 0;
%        NP(12:14,1) = -.5;
%        NP(15,1) = .5;
%        NP(6:10,2) = .5;
% % % 
%      P(:,:) = 0;
% % % %      %Move the constants in the other direction
%          P(1:5,69) = P(1:5,69) + .5;
%          P(6:10,69) = P(6:10,69) - .5;
% % % % % % % %  NP(11,1) = 0;
%          P(12:14,69) = P(12:14,69)+ .5;
%         P(15,69) =  P(15,69) - .5;
%         P(6:10,28) = P(6:10,28)- .5;
% %      
% % %  %NP(12:14,1) = 0;
% % %  %NP(14,1) = -4;
% % % % NP(6:10,2) = -5;
% %     OP(1) = .25;
%       OP(2:5) = .5;
%        OP(9) = 0;
%        OP(8) = 1;
%        OP(7) = 1;

% OP(:) = 0;
% HP(:,:) = 0;
% XP(:,:) = 0;
% OP(7) = 1;
% OP(8) = 1;
% OP(9) = .33;
% % % % %  %OP(1:5) = 0;
%         P(:,:) = 0;
%         XP(:,:) = 0;
%         HP(:,:) = 0;
%         NP(:,:) = 0;
%         XP(6,1) = .2;
%         XP(7,2) = .2;
%         XP(8,3) = .2;
%         XP(9,4) = .2;
% %    NP(1:5,1) = 0;
% %    NP(12:14,1) = 0;    
% %       P(1:5,69) = 0;
% %       P(6:10,28) = 0;
% %       P(6:10,69) = 0;
% %       P(12:15,69) = 0;
%        XP(6:10,1:4) = 1;
% 
NPnew = NP;
Pnew = P;
OPnew = OP;
HPnew = HP;
XPnew = XP;

 %clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda initialschooling Gfirst HP HPnew
 clearvars -except B esim evsim wexpsim N NP NPnew OP OPnew P Pnew PIter Q1 Q2 Q3 Q4 Q QQ QQN QQP r R T Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z LLiter LamdaIter HP HPnew Pvect norsim indLL nvattain QN
 clear mex

clear LLiter LamdaIter PIter indlliter Gfirst

tic
%% 

for r = 1:200;

    %save D:\results\data.mat;
    %clearvars -except X,Y,Z,P,ystar,w,esim,vsim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim
    %open(
 
 for mem = 1:4;   
       
     if mem == 1;
   %try to save memory
        X1 = X(:,:,1:4000);
        esim1 = esim(:,:,:,1:4000);
        %vsim1 = vsim(:,:,:,1:8000);
        evsim1 = evsim(:,:,:,1:4000);
        wexpsim1 = wexpsim(:,:,1:4000);
        norsim1 = norsim(:,:,:,1:4000);
        WW1 = WW(:,:,1:4000);
        Y1 = Y(:,:,1:4000);
        Z1 = Z(:,:,1:4000);
        ystar1 = ystar(1:4000,:);
        w1 = w(1:4000,:);
        nvattain1 = nvattain(:,1:4000);
      %save('xandsim.mat','X','esim','evsim','wexpsim','norsim','WW','Y','Z','ystar','w','nvattain');
      clear X esim evsim wexpsim norsim Y Z WW ystar w nvattain
 
        
        [indLL1,indwageLL,indLLutil,wageLL,indLLchoice,emax2,dindLL1,dwageLL,dutilLL,LLnc04,LLhs00,demax2,choice,sim1ystar,indLchoice,indLwage] = RM35_EE10_2typ_2lvlwexp_all_par1(X1,Y1,Z1,P,ystar1,w1,esim1,W,B,WW1,XP,OP,NP,HP,evsim1,wexpsim1,norsim1,nvattain1); 
     
     clear mex
     
    indLL(1:4000) = indLL1;
    dindLL(1:4000,:) = dindLL1;
     
     load xandsim.mat;
     clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q Q1 Q2 Q3 Q4 QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda HP HPnew norsim indwageLL indLLutil wageLL indLLchoice emax2 dwageLL dutilLL LLnc04 LLhs00 demax2 choice sim1ystar indLchoice indLwage mem nvattain QN; 
     toc

     end
     
     if mem == 2;
   %try to save memory
        X1 = X(:,:,4001:8000);
        esim1 = esim(:,:,:,4001:8000);
        %vsim1 = vsim(:,:,:,1:8000);
        evsim1 = evsim(:,:,:,4001:8000);
        wexpsim1 = wexpsim(:,:,4001:8000);
        norsim1 = norsim(:,:,:,4001:8000);
        WW1 = WW(:,:,4001:8000);
        Y1 = Y(:,:,4001:8000);
        Z1 = Z(:,:,4001:8000);
        ystar1 = ystar(4001:8000,:);
        w1 = w(4001:8000,:);
        nvattain1 = nvattain(:,4001:8000);
      %save('xandsim.mat','X','esim','evsim','wexpsim','norsim','WW','Y','Z','ystar','w','nvattain');
      clear X esim evsim wexpsim norsim Y Z WW ystar w nvattain
 
        
        [indLL1,indwageLL,indLLutil,wageLL,indLLchoice,emax2,dindLL1,dwageLL,dutilLL,LLnc04,LLhs00,demax2,choice,sim1ystar,indLchoice,indLwage] = RM35_EE10_2typ_2lvlwexp_all_par1(X1,Y1,Z1,P,ystar1,w1,esim1,W,B,WW1,XP,OP,NP,HP,evsim1,wexpsim1,norsim1,nvattain1); 
     
     clear mex
     
    indLL(4001:8000) = indLL1;
    dindLL(4001:8000,:) = dindLL1;
     
     load xandsim.mat;
     clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q Q1 Q2 Q3 Q4 QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda HP HPnew norsim indwageLL indLLutil wageLL indLLchoice emax2 dwageLL dutilLL LLnc04 LLhs00 demax2 choice sim1ystar indLchoice indLwage mem nvattain QN; 
     toc

     end
     
     
     if mem == 3;
   %try to save memory
        X1 = X(:,:,8001:12000);
        esim1 = esim(:,:,:,8001:12000);
        %vsim1 = vsim(:,:,:,8001:16197);
        evsim1 = evsim(:,:,:,8001:12000);
        wexpsim1 = wexpsim(:,:,8001:12000);
        norsim1 = norsim(:,:,:,8001:12000);
        WW1 = WW(:,:,8001:12000);
        Y1 = Y(:,:,8001:12000);
        Z1 = Z(:,:,8001:12000);
        ystar1 = ystar(8001:12000,:);
        w1 = w(8001:12000,:);
        nvattain1 = nvattain(:,8001:12000);
      %save('xandsim.mat','X','esim','vsim','evsim','wexpsim','norsim','WW','Y','Z','ystar','w');
      clear X esim evsim wexpsim norsim Y Z WW ystar w nvattain
 
        
        [indLL1,indwageLL,indLLutil,wageLL,indLLchoice,emax2,dindLL1,dwageLL,dutilLL,LLnc04,LLhs00,demax2,choice,sim1ystar,indLchoice,indLwage] = RM35_EE10_2typ_2lvlwexp_all_par1(X1,Y1,Z1,P,ystar1,w1,esim1,W,B,WW1,XP,OP,NP,HP,evsim1,wexpsim1,norsim1,nvattain1); 
     
     clear mex
     
    indLL(8001:12000) = indLL1;
    dindLL(8001:12000,:) = dindLL1;
     
     load xandsim.mat;
     clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q1 Q2 Q3 Q4 Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda HP HPnew norsim indwageLL indLLutil wageLL indLLchoice emax2 dwageLL dutilLL LLnc04 LLhs00 demax2 choice sim1ystar indLchoice indLwage mem nvattain QN; 
     toc
     
     end
     
     
     
     if mem == 4;
   %try to save memory
        X1 = X(:,:,12001:16197);
        esim1 = esim(:,:,:,12001:16197);
        %vsim1 = vsim(:,:,:,8001:16197);
        evsim1 = evsim(:,:,:,12001:16197);
        wexpsim1 = wexpsim(:,:,12001:16197);
        norsim1 = norsim(:,:,:,12001:16197);
        WW1 = WW(:,:,12001:16197);
        Y1 = Y(:,:,12001:16197);
        Z1 = Z(:,:,12001:16197);
        ystar1 = ystar(12001:16197,:);
        w1 = w(12001:16197,:);
        nvattain1 = nvattain(:,12001:16197);
      %save('xandsim.mat','X','esim','vsim','evsim','wexpsim','norsim','WW','Y','Z','ystar','w');
      clear X esim evsim wexpsim norsim Y Z WW ystar w nvattain
 
        
        [indLL1,indwageLL,indLLutil,wageLL,indLLchoice,emax2,dindLL1,dwageLL,dutilLL,LLnc04,LLhs00,demax2,choice,sim1ystar,indLchoice,indLwage] = RM35_EE10_2typ_2lvlwexp_all_parlast(X1,Y1,Z1,P,ystar1,w1,esim1,W,B,WW1,XP,OP,NP,HP,evsim1,wexpsim1,norsim1,nvattain1); 
     
     clear mex
     
    indLL(12001:16197) = indLL1;
    dindLL(12001:16197,:) = dindLL1;
     
     load xandsim.mat;
     clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q1 Q2 Q3 Q4 Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda HP HPnew norsim indwageLL indLLutil wageLL indLLchoice emax2 dwageLL dutilLL LLnc04 LLhs00 demax2 choice sim1ystar indLchoice indLwage mem nvattain QN; 
     toc
     
     end
              
 end


% toc
% clock

%clearvars -except B C dindLL elsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda initialschooling Gfirst HP HPnew

%% 

% dindLLpar = zeros(N,QQ,2);
% indLLpar = zeros(N,1,2);
% wageLLpar = zeros(N,T,2);
% indLLchoicepar = zeros(N,T,2);



%toc
%clock

%save D:\results\currentdata2.mat;
 
%  for i = 1:N;
%     for j = 1:QQ;
%     if dindLL(i,j) == inf;
%         dindLL(i,j) = 500;
%     end
%     end
%  end


 %%First calculate likelyhood with only one EE
 [indLL,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim,norsim,nvattain); 
 
  LLikely = sum(indLL);
 clear mex
 toc
 
 isnan(LLikely);
    if ans == 1;
        break
    end
 
 %Find derivatives for percent variables
 % First for wage parameter
% 
OPderiv = OP;
OPderiv(2) = OP(2) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv2 = (indLLderiv - indLL)/.001; 
 
clear mex 

OPderiv = OP;
OPderiv(3) = OP(3) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv3 = (indLLderiv - indLL)/.001; 
 
clear mex 

OPderiv = OP;
OPderiv(4) = OP(4) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv4 = (indLLderiv - indLL)/.001; 
 
clear mex 

OPderiv = OP;
OPderiv(5) = OP(5) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv5 = (indLLderiv - indLL)/.001; 
 
clear mex 


OPderiv = OP;
OPderiv(7) = OP(7) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv7 = (indLLderiv - indLL)/.001; 
 
clear mex 

OPderiv = OP;
OPderiv(8) = OP(8) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv8 = (indLLderiv - indLL)/.001; 
 
clear mex 

OPderiv = OP;
OPderiv(9) = OP(9) + .001;
[indLLderiv,b14,b15,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OPderiv,NP,HP,evsim,wexpsim,norsim,nvattain); 
deriv9 = (indLLderiv - indLL)/.001; 
 
clear mex 

% clear mex
 toc

G = [dindLL,deriv2,deriv3,deriv4,deriv5,deriv7,deriv8,deriv9];


%dindlliter(:,:,r) = G;  
%clearvars -except B C dindLL elsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda initialschooling Gfirst HP HPnew


%keep only the first G matrix matrix
% if r == 1;
%     Gfirst = zeros(N,QQP);
%     Gfirst = G;
% end
% if r > 1;
    %Gfirst(:,:,r) = G(:,:);
% end


grad = sum(G, 1)/N;
%The outer product of each individuals score functions.  third dimension is individuals, first and second dimensions are the outerproducts
%outprod = zeros(Q,Q,N);
%Populate the outer product for each individual (i=1-14) in the first two dimensions of "outprod")

%For memory reasons, only save bits of outprod at a time
D = zeros(QQP,QQP);
for j = 1:QQP;
    for k = 1:QQP;
        outprod = zeros(N,1);
        for i =1:N;
        outprod(i) = G(i,j)*G(i,k);
        end

%Create the average outer product in the sample

        D(j,k) = sum(outprod)/N;
    end
end
%Create the inverse of this average outer product
toc

%Diter(:,:,r) = D;

Binv = inv(D);

    if r == 1;
    save D:\results\firstiter.mat;
    end
    
    isnan(Binv(1,1));
    if ans == 1;
        break
    end
    if Binv(1,1) == inf;
        break
    end
  
 
Pvect(1:va) = P(1,29:41);
Pvect(va+1:2*va) = P(2,29:41);
Pvect(2*va+1:3*va) =  P(3,29:41);
Pvect(3*va+1:4*va) =  P(4,29:41);
Pvect(4*va+1:5*va) =  P(5,29:41); 
Pvect(5*va+1:5*va+2) = P(3,47:48); 
Pvect(5*va+3:5*va+4) =  P(4,49:50); 
Pvect(5*va+5) = P(1,51);
Pvect(5*va+6) = P(2,51);
Pvect(5*va+7:5*va+13) = P(3,52:58);
Pvect(5*va+14:5*va+20) =P(4,52:58);
Pvect(5*va+21:5*va+27) = P(5,52:58);
Pvect(5*va+28:vb) = P(1:5,69);
Pvect(vb+1:vb+8) = P(1,59:66); 
Pvect(vb+9:vb+16) = P(2,59:66); 
Pvect(vb+17:vb+24) = P(3,59:66);
Pvect(vb+25:vb+32) = P(4,59:66); 
Pvect(vb+33:VHS) = P(5,59:66);
Pvect(VHS+1:VHS+vc) = P(6,1:41);
Pvect(VHS+vc+1:VHS+2*vc) = P(7,1:41);
Pvect(VHS+2*vc+1:VHS+3*vc) = P(8,1:41);
Pvect(VHS+3*vc+1:VHS+4*vc) = P(9,1:41); 
Pvect(VHS+4*vc+1:VHS+5*vc) = P(10,1:41);
Pvect(VHS+5*vc+1:VW) = P(6:10,69);
Pvect(VW+1) = P(12,1);
Pvect(VW+2) = P(13,1);
Pvect(VW+3) = P(14,1);
Pvect(VW+4:VW+7) = P(12,3:6);
Pvect(VW+8:VW+11) =  P(13,3:6); 
Pvect(VW+12:VW+15) =  P(14,3:6); 
Pvect(VW+16:VW+15+va) = P(12,29:41); 
Pvect(VW+16+va:VW+15+2*va) = P(13,29:41); 
Pvect(VW+16+2*va:VW+15+3*va) = P(14,29:41); 
Pvect(VW+16+3*va:VW+15+3*va+vd) = P(12,63:69); 
Pvect(VW+16+3*va+vd:VW+15+3*va+2*vd) = P(13,63:69);
Pvect(VW+16+3*va+2*vd:Q1) = P(14,63:69);
Pvect(Q1+1:Q1+va) = P(15,29:41);
Pvect(Q1+1+va:Q2-2) = P(15,59:66);
Pvect(Q2-1:Q2) = P(15,69:70);  

Pvect(Q2+1) = XP(6,1);
Pvect(Q2+2) = XP(7,2);
Pvect(Q2+3) = XP(8,3);
Pvect(Q2+4) = XP(9,4);   
  
Pvect(Q3+1:Q3+10) = NP(1:10,1);
Pvect(Q3+11:Q3+14) = NP(12:15,1);
Pvect(Q3+15:Q4) = NP(6:10,2);

Pvect(Q4+1:Q4+2) = HP(7,3:4);
Pvect(Q4+3:Q4+4) = HP(8,3:4);

Pvect(QQ+1) = OP(2);
Pvect(QQ+2) = OP(3);
Pvect(QQ+3) = OP(4);
Pvect(QQ+4) = OP(5);
Pvect(QQ+5) = OP(7);
Pvect(QQ+6) = OP(8);
Pvect(QQ+7) = OP(9);


% [indLLsing,indwageLLnew,indLLutilnew,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = a2_1_16_RUNNINGMAN11_fixed2_likelyonly(X,Y,Z,P,ystar,w,elsim,vsim,W,B,WW,XP,OP,NP,HP); 
% LLikelysing = sum(indLLsing);
%  

LLiter(:,r)=LLikely;
%indlliter(:,r) = indLL;

clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q1 Q2 Q3 Q4 Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda HP HPnew norsim demax2 nvattain QN
clear mex
toc

%% 
lamda = 2;
LLsmaller = -999999999999999999999999999999999999999;
while lamda>.00005 & LLikely>LLsmaller;

lamda = lamda/2;
Pvectnew = Pvect + lamda*(Binv*grad');

        %Make sure percentage type is between zero and one
%         if Pvectnew(QQ+3) >= 1;
%             Pvectnew(QQ+3) = 0.95;
%         end
%         if Pvectnew(QQ+3) <= 0;
%             Pvectnew(QQ+3) = 0.05;
%         end
%         if Pvectnew(QQ+1) <= 0;
%             Pvectnew(QQ+1) = 0.05;
%         end

Pnew(1,29:41) =   Pvectnew(1:va);
 Pnew(2,29:41) =   Pvectnew(va+1:2*va);
 Pnew(3,29:41) =   Pvectnew(2*va+1:3*va);
 Pnew(4,29:41) =   Pvectnew(3*va+1:4*va);
 Pnew(5,29:41) =   Pvectnew(4*va+1:5*va);
 Pnew(3,47:48) =   Pvectnew(5*va+1:5*va+2);
 Pnew(4,49:50) =   Pvectnew(5*va+3:5*va+4);
 Pnew(1,51)    =   Pvectnew(5*va+5);
 Pnew(2,51)    =   Pvectnew(5*va+6);
 Pnew(3,52:58) =   Pvectnew(5*va+7:5*va+13);
 Pnew(4,52:58) =   Pvectnew(5*va+14:5*va+20);
 Pnew(5,52:58) =   Pvectnew(5*va+21:5*va+27);
 Pnew(1:5,69)  =   Pvectnew(5*va+28:vb);
 Pnew(1,59:66) =   Pvectnew(vb+1:vb+8);
 Pnew(2,59:66) =   Pvectnew(vb+9:vb+16);
 Pnew(3,59:66) =   Pvectnew(vb+17:vb+24);
 Pnew(4,59:66) =   Pvectnew(vb+25:vb+32);
 Pnew(5,59:66) =   Pvectnew(vb+33:VHS);
 Pnew(6,1:41)  =   Pvectnew(VHS+1:VHS+vc);
 Pnew(7,1:41)  =   Pvectnew(VHS+vc+1:VHS+2*vc);
 Pnew(8,1:41)  =   Pvectnew(VHS+2*vc+1:VHS+3*vc);
 Pnew(9,1:41)  =   Pvectnew(VHS+3*vc+1:VHS+4*vc);
 Pnew(10,1:41) =   Pvectnew(VHS+4*vc+1:VHS+5*vc); 
 Pnew(6:10,69) =   Pvectnew(VHS+5*vc+1:VW); 
 Pnew(12,1)    =   Pvectnew(VW+1);
 Pnew(13,1)    =   Pvectnew(VW+2);
 Pnew(14,1)    =   Pvectnew(VW+3);
 Pnew(12,3:6)  =   Pvectnew(VW+4:VW+7);
 Pnew(13,3:6)  =   Pvectnew(VW+8:VW+11);
 Pnew(14,3:6)  =   Pvectnew(VW+12:VW+15);
 Pnew(12,29:41)=   Pvectnew(VW+16:VW+15+va);
 Pnew(13,29:41)=   Pvectnew(VW+16+va:VW+15+2*va);
 Pnew(14,29:41)=   Pvectnew(VW+16+2*va:VW+15+3*va);
 Pnew(12,63:69)=   Pvectnew(VW+16+3*va:VW+15+3*va+vd);
 Pnew(13,63:69)=   Pvectnew(VW+16+3*va+vd:VW+15+3*va+2*vd);
 Pnew(14,63:69)=   Pvectnew(VW+16+3*va+2*vd:Q1);
 Pnew(15,29:41)=   Pvectnew(Q1+1:Q1+va);
 Pnew(15,59:66) =   Pvectnew(Q1+1+va:Q2-2);
 Pnew(15,69:70)   =   Pvectnew(Q2-1:Q2);
 
 XPnew(6,1) = Pvectnew(Q2+1);
 XPnew(7,2) = Pvectnew(Q2+2);
 XPnew(8,3) = Pvectnew(Q2+3);
 XPnew(9,4) = Pvectnew(Q3);

 NPnew(1:10,1) = Pvectnew(Q3+1:Q3+10);
 NPnew(12:15,1) = Pvectnew(Q3+11:Q3+14);
 NPnew(6:10,2) = Pvectnew(Q3+15:Q4);
 
 HPnew(7,3:4) = Pvectnew(Q4+1:Q4+2);
 HPnew(8,3:4) = Pvectnew(Q4+3:Q4+4);

OPnew(2) =   Pvectnew(QQ+1);
OPnew(3) =   Pvectnew(QQ+2);
OPnew(4) =   Pvectnew(QQ+3);
OPnew(5) =   Pvectnew(QQ+4);
OPnew(7) =   Pvectnew(QQ+5);
OPnew(8) =   Pvectnew(QQ+6);
OPnew(9) =   Pvectnew(QQ+7);
 

%%%%
%%%%
 

 [indLLnew,indwageLLnew,indLLutilnew,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,Pnew,ystar,w,esim,W,B,WW,XPnew,OPnew,NPnew,HPnew,evsim,wexpsim,norsim,nvattain); 
%[indLLnew,indwageLLnew,indLLutilnew,b1,b2,b3] = likely(N,T,E,Pnew,e,X,Y,Z,elsim,S,ystar,vsim,wob,w,W,B,Tstar,Tdubstar);
% for i = 1:N;
%     if indLLnew(i) == inf;
%         indLLnew(i) = 0;
%     end
% end
clear mex

LLsmaller = sum(indLLnew);
    isnan(LLsmaller);
    if ans == 1;
    LLnext = -999999999999999999999999999999999999999;
    end
   
end


if lamda == 1;
    LLnext = LLsmaller;
    
    LLfirst = -999999999999999999999999999999999999999;    
    while LLnext>LLfirst;
    lamda = lamda*2;
    LLfirst = LLnext;
    Pvectnew = Pvect + lamda*(Binv*grad');
    %Reshape those values into the 4 by 3 matrix
    % Pnewprime = reshape(Pvectnew,V,C-1);
    % Pnew = Pnewprime';
    % Pstep = [Pnew;z];   
 
         %Make sure percentage type is between zero and one
%         if Pvectnew(QQ+3) >= 1;
%             Pvectnew(QQ+3) = 0.95;
%         end
%         if Pvectnew(QQ+3) <= 0;
%             Pvectnew(QQ+3) = 0.05;
%         end
%         end   
%         if Pvectnew(QQ+1) <= 0;
%             Pvectnew(QQ+1) = 0.07;
%         end
  

Pnew(1,29:41) =   Pvectnew(1:va);
 Pnew(2,29:41) =   Pvectnew(va+1:2*va);
 Pnew(3,29:41) =   Pvectnew(2*va+1:3*va);
 Pnew(4,29:41) =   Pvectnew(3*va+1:4*va);
 Pnew(5,29:41) =   Pvectnew(4*va+1:5*va);
 Pnew(3,47:48) =   Pvectnew(5*va+1:5*va+2);
 Pnew(4,49:50) =   Pvectnew(5*va+3:5*va+4);
 Pnew(1,51)    =   Pvectnew(5*va+5);
 Pnew(2,51)    =   Pvectnew(5*va+6);
 Pnew(3,52:58) =   Pvectnew(5*va+7:5*va+13);
 Pnew(4,52:58) =   Pvectnew(5*va+14:5*va+20);
 Pnew(5,52:58) =   Pvectnew(5*va+21:5*va+27);
 Pnew(1:5,69)  =   Pvectnew(5*va+28:vb);
 Pnew(1,59:66) =   Pvectnew(vb+1:vb+8);
 Pnew(2,59:66) =   Pvectnew(vb+9:vb+16);
 Pnew(3,59:66) =   Pvectnew(vb+17:vb+24);
 Pnew(4,59:66) =   Pvectnew(vb+25:vb+32);
 Pnew(5,59:66) =   Pvectnew(vb+33:VHS);
 Pnew(6,1:41)  =   Pvectnew(VHS+1:VHS+vc);
 Pnew(7,1:41)  =   Pvectnew(VHS+vc+1:VHS+2*vc);
 Pnew(8,1:41)  =   Pvectnew(VHS+2*vc+1:VHS+3*vc);
 Pnew(9,1:41)  =   Pvectnew(VHS+3*vc+1:VHS+4*vc);
 Pnew(10,1:41) =   Pvectnew(VHS+4*vc+1:VHS+5*vc); 
 Pnew(6:10,69) =   Pvectnew(VHS+5*vc+1:VW); 
 Pnew(12,1)    =   Pvectnew(VW+1);
 Pnew(13,1)    =   Pvectnew(VW+2);
 Pnew(14,1)    =   Pvectnew(VW+3);
 Pnew(12,3:6)  =   Pvectnew(VW+4:VW+7);
 Pnew(13,3:6)  =   Pvectnew(VW+8:VW+11);
 Pnew(14,3:6)  =   Pvectnew(VW+12:VW+15);
 Pnew(12,29:41)=   Pvectnew(VW+16:VW+15+va);
 Pnew(13,29:41)=   Pvectnew(VW+16+va:VW+15+2*va);
 Pnew(14,29:41)=   Pvectnew(VW+16+2*va:VW+15+3*va);
 Pnew(12,63:69)=   Pvectnew(VW+16+3*va:VW+15+3*va+vd);
 Pnew(13,63:69)=   Pvectnew(VW+16+3*va+vd:VW+15+3*va+2*vd);
 Pnew(14,63:69)=   Pvectnew(VW+16+3*va+2*vd:Q1);
 Pnew(15,29:41)=   Pvectnew(Q1+1:Q1+va);
 Pnew(15,59:66) =   Pvectnew(Q1+1+va:Q2-2);
 Pnew(15,69:70)   =   Pvectnew(Q2-1:Q2);
 
 XPnew(6,1) = Pvectnew(Q2+1);
 XPnew(7,2) = Pvectnew(Q2+2);
 XPnew(8,3) = Pvectnew(Q2+3);
 XPnew(9,4) = Pvectnew(Q3);

 NPnew(1:10,1) = Pvectnew(Q3+1:Q3+10);
 NPnew(12:15,1) = Pvectnew(Q3+11:Q3+14);
 NPnew(6:10,2) = Pvectnew(Q3+15:Q4);
 
 HPnew(7,3:4) = Pvectnew(Q4+1:Q4+2);
 HPnew(8,3:4) = Pvectnew(Q4+3:Q4+4);

OPnew(2) =   Pvectnew(QQ+1);
OPnew(3) =   Pvectnew(QQ+2);
OPnew(4) =   Pvectnew(QQ+3);
OPnew(5) =   Pvectnew(QQ+4);
OPnew(7) =   Pvectnew(QQ+5);
OPnew(8) =   Pvectnew(QQ+6);
OPnew(9) =   Pvectnew(QQ+7);
 
 
 %  %Create a variable for the cross effects of each high school voc and 1 yearvoc school
%  NP(6:10,3:5) = 1;
% %work utilty from school choices
  %NP(6:10,6:13) = 1;
  

 
 [indLLnew,indwageLLnew,indLLutilnew,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13] = RM35_EE10_2typ_2lvlwexp_likelyonly(X,Y,Z,Pnew,ystar,w,esim,W,B,WW,XPnew,OPnew,NPnew,HPnew,evsim,wexpsim,norsim,nvattain); 
%[indLLnew,indwageLLnew,indLLutilnew,b1,b2,b3] = likely(N,T,E,Pnew,e,X,Y,elsim,S,ystar,vsim,wob,w,W,B,Tstar,Tdubstar);
% for i = 1:N;
%     if indLLnew(i) == inf;
%         indLLnew(i) = 0;
%     end
% end
clear mex

LLnext = sum(indLLnew);
    isnan(LLnext);
    if ans == 1;
    LLnext = -999999999999999999999999999999999999999;
    end

    end
        %Use the lamda that produced the highest liklihood function
        lamda = lamda/2;
        Pvectnew = Pvect + lamda*(Binv*grad');
 
           %Make sure percentage type is between zero and one
%         if Pvectnew(QQ+3) >= 1;
%             Pvectnew(QQ+3) = 0.95;
%         end
%         if Pvectnew(QQ+3) <= 0;
%             Pvectnew(QQ+3) = 0.05;
%         end
            
%         if Pvectnew(QQ+1) <= 0;
%             Pvectnew(QQ+1) = 0.07;
%         end
        
% 

 Pnew(1,29:41) =   Pvectnew(1:va);
 Pnew(2,29:41) =   Pvectnew(va+1:2*va);
 Pnew(3,29:41) =   Pvectnew(2*va+1:3*va);
 Pnew(4,29:41) =   Pvectnew(3*va+1:4*va);
 Pnew(5,29:41) =   Pvectnew(4*va+1:5*va);
 Pnew(3,47:48) =   Pvectnew(5*va+1:5*va+2);
 Pnew(4,49:50) =   Pvectnew(5*va+3:5*va+4);
 Pnew(1,51)    =   Pvectnew(5*va+5);
 Pnew(2,51)    =   Pvectnew(5*va+6);
 Pnew(3,52:58) =   Pvectnew(5*va+7:5*va+13);
 Pnew(4,52:58) =   Pvectnew(5*va+14:5*va+20);
 Pnew(5,52:58) =   Pvectnew(5*va+21:5*va+27);
 Pnew(1:5,69)  =   Pvectnew(5*va+28:vb);
 Pnew(1,59:66) =   Pvectnew(vb+1:vb+8);
 Pnew(2,59:66) =   Pvectnew(vb+9:vb+16);
 Pnew(3,59:66) =   Pvectnew(vb+17:vb+24);
 Pnew(4,59:66) =   Pvectnew(vb+25:vb+32);
 Pnew(5,59:66) =   Pvectnew(vb+33:VHS);
 Pnew(6,1:41)  =   Pvectnew(VHS+1:VHS+vc);
 Pnew(7,1:41)  =   Pvectnew(VHS+vc+1:VHS+2*vc);
 Pnew(8,1:41)  =   Pvectnew(VHS+2*vc+1:VHS+3*vc);
 Pnew(9,1:41)  =   Pvectnew(VHS+3*vc+1:VHS+4*vc);
 Pnew(10,1:41) =   Pvectnew(VHS+4*vc+1:VHS+5*vc); 
 Pnew(6:10,69) =   Pvectnew(VHS+5*vc+1:VW); 
 Pnew(12,1)    =   Pvectnew(VW+1);
 Pnew(13,1)    =   Pvectnew(VW+2);
 Pnew(14,1)    =   Pvectnew(VW+3);
 Pnew(12,3:6)  =   Pvectnew(VW+4:VW+7);
 Pnew(13,3:6)  =   Pvectnew(VW+8:VW+11);
 Pnew(14,3:6)  =   Pvectnew(VW+12:VW+15);
 Pnew(12,29:41)=   Pvectnew(VW+16:VW+15+va);
 Pnew(13,29:41)=   Pvectnew(VW+16+va:VW+15+2*va);
 Pnew(14,29:41)=   Pvectnew(VW+16+2*va:VW+15+3*va);
 Pnew(12,63:69)=   Pvectnew(VW+16+3*va:VW+15+3*va+vd);
 Pnew(13,63:69)=   Pvectnew(VW+16+3*va+vd:VW+15+3*va+2*vd);
 Pnew(14,63:69)=   Pvectnew(VW+16+3*va+2*vd:Q1);
 Pnew(15,29:41)=   Pvectnew(Q1+1:Q1+va);
 Pnew(15,59:66) =   Pvectnew(Q1+1+va:Q2-2);
 Pnew(15,69:70)   =   Pvectnew(Q2-1:Q2);
 
 XPnew(6,1) = Pvectnew(Q2+1);
 XPnew(7,2) = Pvectnew(Q2+2);
 XPnew(8,3) = Pvectnew(Q2+3);
 XPnew(9,4) = Pvectnew(Q3);

 NPnew(1:10,1) = Pvectnew(Q3+1:Q3+10);
 NPnew(12:15,1) = Pvectnew(Q3+11:Q3+14);
 NPnew(6:10,2) = Pvectnew(Q3+15:Q4);
 
 HPnew(7,3:4) = Pvectnew(Q4+1:Q4+2);
 HPnew(8,3:4) = Pvectnew(Q4+3:Q4+4);

OPnew(2) =   Pvectnew(QQ+1);
OPnew(3) =   Pvectnew(QQ+2);
OPnew(4) =   Pvectnew(QQ+3);
OPnew(5) =   Pvectnew(QQ+4);
OPnew(7) =   Pvectnew(QQ+5);
OPnew(8) =   Pvectnew(QQ+6);
OPnew(9) =   Pvectnew(QQ+7);
 


end
 

 


%Save the old values
 PIter(:,r)=Pvectnew;
 LamdaIter(:,r)=lamda;
 %dindLLiter(:,:,r)=dindLL;


%Replace the old values with the new values
P = Pnew;
XP = XPnew;
NP = NPnew;
OP = OPnew;
HP = HPnew;

save D:\results\currentdata2.mat;


clearvars -except B C dindLL esim evsim wexpsim indLL N NP NPnew OP OPnew P Pnew PIter Pvect Pvectnew Q1 Q2 Q3 Q4 Q QQ QQN QQP r R T Tdubstar Tstar V va vb vc vd VHS vsim VW w W WW X XP XPnew Y ystar Z D Binv grad G LLiter LamdaIter indlliter LLikely LLsmaller LLnext LLfirst lamda initialschooling Gfirst HP HPnew norsim demax2 nvattain QN
clear mex

toc
clock
% %Make the step size adjustment
%   %Calculate the likelyhood given this new P.  If it is higher then the old likelyhood, then proceed.  If not, cut lamda in 2 and try again 
%     %We will calculate the likelyhood for each individual individually (i=1-14) i = individual 
% for i = 1:n;
%   %j = option chosen (4 options available, the option chosen is in row 1 of matrix Data).  If they chose a particular option, we will evaluate the probability that they chose that option
%     for j= 1:c;
%   %First calculate the likelihood for the individuals if they chose option 1. (j=1).  Then calculate it for the individual if they instead chose option 2, 3, or 4, respectively.  Note that I allow the variance of the errors to be very large (t, defined above)   
%         if Data(1,i) == j;
%             %This is equivilent to Prob(u(j)>u(-j)) = (e^(xb(j)/t))/(sum(over j)(xb/t))
%             indlikely(i,1) = (exp((P(j)*Data(2,i))/t))/(exp((P(1)*Data(2,i))/t)+exp((P(2)*Data(2,i))/t));
%         end
%     end
% %end
% 
% %Take logs if individual likelyhood functions
% indLL = log(indlikely);
% 
% %The overall likelyhood funtion is the product of these probabilities
% Likely = prod(indlikely);
% LLnext = log(Likely);
% end
% 
% 
% Pvect = reshape(P,v,1)
% %******Back to the start to run the inner loop with the new parameter values

end
 