%Generate Standard Deviations

%First create variance for each individual from the Hessian Approximation (See Train book)
H = zeros(QQN,1);
for i = 1:QQN;
    H(i) = Binv(i,i);
end
    
varall = zeros(QQN,1);
varsome = zeros(QQN,1);
varall = H/N;
varsome = H/12443;



%Put them in the same order as the P's

 Pvar(1,29:41) =   varall(1:va);
 Pvar(2,29:41) =   varall(va+1:2*va);
 Pvar(3,29:41) =   varall(2*va+1:3*va);
 Pvar(4,29:41) =   varall(3*va+1:4*va);
 Pvar(5,29:41) =   varall(4*va+1:5*va);
 Pvar(3,47:48) =   varall(5*va+1:5*va+2);
 Pvar(4,49:50) =   varall(5*va+3:5*va+4);
 Pvar(1,51)    =   varall(5*va+5);
 Pvar(2,51)    =   varall(5*va+6);
 Pvar(3,52:58) =   varall(5*va+7:5*va+13);
 Pvar(4,52:58) =   varall(5*va+14:5*va+20);
 Pvar(5,52:58) =   varall(5*va+21:5*va+27);
 Pvar(1:5,69)  =   varall(5*va+28:vb);
 Pvar(1,59:66) =   varall(vb+1:vb+8);
 Pvar(2,59:66) =   varall(vb+9:vb+16);
 Pvar(3,59:66) =   varall(vb+17:vb+24);
 Pvar(4,59:66) =   varall(vb+25:vb+32);
 Pvar(5,59:66) =   varall(vb+33:VHS);
 Pvar(6,1:41)  =   varall(VHS+1:VHS+vc);
 Pvar(7,1:41)  =   varall(VHS+vc+1:VHS+2*vc);
 Pvar(8,1:41)  =   varall(VHS+2*vc+1:VHS+3*vc);
 Pvar(9,1:41)  =   varall(VHS+3*vc+1:VHS+4*vc);
 Pvar(10,1:41) =   varall(VHS+4*vc+1:VHS+5*vc); 
 Pvar(6:10,69) =   varall(VHS+5*vc+1:VW); 
 Pvar(12,1)    =   varall(VW+1);
 Pvar(13,1)    =   varall(VW+2);
 Pvar(14,1)    =   varall(VW+3);
 Pvar(12,3:6)  =   varall(VW+4:VW+7);
 Pvar(13,3:6)  =   varall(VW+8:VW+11);
 Pvar(14,3:6)  =   varall(VW+12:VW+15);
 Pvar(12,29:41)=   varall(VW+16:VW+15+va);
 Pvar(13,29:41)=   varall(VW+16+va:VW+15+2*va);
 Pvar(14,29:41)=   varall(VW+16+2*va:VW+15+3*va);
 Pvar(12,63:69)=   varall(VW+16+3*va:VW+15+3*va+vd);
 Pvar(13,63:69)=   varall(VW+16+3*va+vd:VW+15+3*va+2*vd);
 Pvar(14,63:69)=   varall(VW+16+3*va+2*vd:Q1);
 Pvar(15,29:41)=   varall(Q1+1:Q1+va);
 Pvar(15,59:66) =   varall(Q1+1+va:Q2-2);
 Pvar(15,69:70)  =   varall(Q2-1:Q2);
 
 XPvar(6,1) = varall(Q2+1);
 XPvar(7,2) = varall(Q2+2);
 XPvar(8,3) = varall(Q2+3);
 XPvar(9,4) = varall(Q3);

 NPvar(1:10,1) = varall(Q3+1:Q3+10);
 NPvar(12:15,1) = varall(Q3+11:Q3+14);
 NPvar(6:10,2) = varall(Q3+15:Q4);
 
 HPvar(7,3:4) = varall(Q4+1:Q4+2);
 HPvar(8,3:4) = varall(Q4+3:Q4+4);

OPvar(2) =   varall(QQ+1);
OPvar(3) =   varall(QQ+2);
OPvar(4) =   varall(QQ+3);
OPvar(5) =   varall(QQ+4);
OPvar(7) =   varall(QQ+5);
OPvar(8) =   varall(QQ+6);
OPvar(9) =   varall(QQ+7);