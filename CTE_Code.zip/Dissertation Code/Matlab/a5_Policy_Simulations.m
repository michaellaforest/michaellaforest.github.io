%Run Policy Simulations

tic


%% 


%Run the Data
[indLL1,indwageLL1,indLLutil1,wageLL1,indLLchoice1,emax21,dindLL1,dwageLL1,dutilLL1,LLnc041,LLhs001,demax21,choice1,sim1ystar1,indLchoice1,indLwage1] = PolSim_EE10_2typ_2lvlwexp_datasim_typ(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim,norsim,nvattain);

clear mex
likely = sum(indLL1)

%% 
%Run the simulation
[indLL1,indwageLL1,indLLutil1,wageLL1,indLLchoice1,emax21,dindLL1,dwageLL1,dutilLL1,LLnc041,LLhs001,demax21,choice1,sim1ystar1,indLchoice1,indLwage1] = PolSim_EE10_2typ_2lvlwexp_util(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim,norsim,nvattain);

clear mex


%% 

%Create outcome variables after running the simulation


%Run twice, for each type of unobserved heterogeneity type
 %ystarsim = transpose(indLwage12);
 ystarsim = transpose(indLchoice12);

 %Create information for years of each type of HS curricula
 Ypol = zeros(5,T,N);
 %Add initial conditions for students who were ahead in 00
 for i = 1:N;
    Ypol(2,1,i) = Y(2,1,i);
 end


        %Next, update the state space vector Ypol for period 2
for i = 1:N;
    for k = 1:T;       
        Ypol(:,k+1,i) = Ypol(:,k,i);

            if ystarsim(i,k) == 1;
                Ypol(1,k+1,i) = Ypol(1,k,i) + 1;
            end
            if ystarsim(i,k) == 2;
                Ypol(2,k+1,i) = Ypol(2,k,i) + 1;
            end
            if ystarsim(i,k) == 3;
                Ypol(3,k+1,i) = Ypol(3,k,i) + 1;
            end
            if ystarsim(i,k) == 4;
                Ypol(4,k+1,i) = Ypol(4,k,i) + 1;
            end
            if ystarsim(i,k) == 5;
                Ypol(5,k+1,i) = Ypol(5,k,i) + 1;
            end
     end
end

Xpol = zeros(9,T,N);
        %Finally, update the state space vector Xpol for period 2
for i = 1:N;
    for k = 1:T;       
        Xpol(:,k+1,i) = Xpol(:,k,i);

        %If you graduated from high school this year
        if Ypol(1,k+1,i) + Ypol(2,k+1,i) + Ypol(3,k+1,i) + Ypol(4,k+1,i) + Ypol(5,k+1,i) == 4
            if Ypol(1,k,i) + Ypol(2,k,i) + Ypol(3,k,i) + Ypol(4,k,i) + Ypol(5,k,i) == 3
                 
                %Trade voc no matter what
                   if Ypol(4,k,i) >= 2 && Ypol(3,k,i) == 0;
                        Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                   end

                %bus voc no matter what
                   if Ypol(3,k,i) >= 2 && Ypol(4,k,i) == 0;
                       Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                   end
                   
                %other voc no matter what
                   if Ypol(5,k,i) >= 2 && Ypol(4,k,i) == 0 && Ypol(3,k,i) == 0;
                       Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                   end
                   
                %Trade voc unless bus voc
                   if Ypol(4,k,i) >= 2 && Ypol(3,k,i) == 1;
                        if ystarsim(i,k) ~= 3;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;  
                        end
                   end
                  
                %Bus voc unless trade voc
                   if Ypol(3,k,i) >= 2 && Ypol(4,k,i) == 1;
                        if ystarsim(i,k) ~= 4;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless trade voc
                   if Ypol(5,k,i) >= 2 && Ypol(4,k,i) == 1;
                        if ystarsim(i,k) ~= 4;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless bus voc
                   if Ypol(5,k,i) >= 2 && Ypol(3,k,i) == 1;
                        if ystarsim(i,k) ~= 3;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;  
                        end
                   end
                           
                %No more then one year of any voc/academic curricula (curicula is whatever you choose senior year)                                                            
                   if Ypol(3,k,i) <= 1 && Ypol(4,k,i) <=1 && Ypol(5,k,i) <= 1 && Ypol(1,k,i) <=1;
                        if ystarsim(i,k) == 1;
                            Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                        end
                        if ystarsim(i,k) == 2;
                            Xpol(2,k+1,i) = Xpol(2,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 5;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                   end
                                              
                 %Academic equal to 2 and all voc equal to 0 or 1 (implied)
                   if Ypol(1,k,i) == 2;
                        if ystarsim(i,k) >= 1 && ystarsim(i,k) <=2;
                            Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 5;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                   end
                   
                  %Academic equal to 3 (academic no matter what)
                   if Ypol(1,k,i) == 3;
                        Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                   end
                                          
            end
        end
        
        %GED completion
        if ystarsim(i,k) == 15
           Xpol(6,k+1,i) = Xpol(6,k,i) + 1; 
        end
        
     end
end 


%Create information for years of each type of college graduation
 Zpol = zeros(3,T,N);

        %Next, update the state space vector Ypol for period 2
for i = 1:N;
    for k = 1:T; 
        Zpol(:,k+1,i) = Zpol(:,k,i);

            if ystarsim(i,k) == 12;
                Zpol(1,k+1,i) = Zpol(1,k,i) + 1;
            end
            if ystarsim(i,k) == 13;
                Zpol(2,k+1,i) = Zpol(2,k,i) + 1;
            end
            if ystarsim(i,k) == 14;
                Zpol(3,k+1,i) = Zpol(3,k,i) + 1;
            end
     end
end

        %Finally, update the state space vector Xpol for period 2
for i = 1:N;
    for k = 1:T;       
        Xpol(7:9,k+1,i) = Xpol(7:9,k,i);
        %PSX(6:8,k+1,i) = PSX(6:8,k,i);
        
        %If you graduated from trade school this year
        if ystarsim(i,k) == 12;
             Xpol(7,k+1,i) = Xpol(7,k,i) + 1;
             %PSX(6,k+1,i) = PSX(6,k,i) + 1;
        end
             
        %If you graduated from community college this year
        if Zpol(2,k,i) == 1;
            if Zpol(2,k+1,i) == 2;
                 Xpol(8,k+1,i) = Xpol(8,k,i) + 1;
                 %PSX(7,k+1,i) = PSX(7,k,i) + 1;
            end
        end
                
        %If you graduated from university this year
        if Zpol(3,k,i) == 3;
            if Zpol(3,k+1,i) == 4;
                 Xpol(9,k+1,i) = Xpol(9,k,i) + 1;
                 %PSX(8,k+1,i) = PSX(8,k,i) + 1;
                                          
            end
        end
        
     end
end 


Xpolsim = Xpol(:,14,:);
Xpolsim = squeeze(Xpolsim);
Xpolsim = Xpolsim';
%have to copy: Xpolsim (education), ystarsim(13) (final choice), and wagesim(13) final wages


%Then: average wages
%average work choice final period
%Overall HS track choices
%Overall PSE attainment
%Same broken down by type?


%Easier to put in stata?
%Average wages
%avwagepol = mean(nonzero(wagesim(:,13)));



%% 

%Make these changes prior to the simulation to conduct each policy simulation

%policy sim 1: every school offers voc in school
%Voc in school
for i = 1:N;
    if X(54,:,i) == 0 & X(52,:,i) == 0;
        %if not already in area school
        if X(53,:,i) == 0;
             X(52,:,:) = 1;
        end
        %If already in area school
        if X(53,:,i) == 1;
             X(54,:,:) = 1;
             X(53,:,i) = 0;
        end
    end
    
%marketing and precisions in school
    if X(47,:,i) == 0;
        X(47,:,i) = 1;
        X(48,:,i) = 0;
    end
    %Strangely, area precisions is better than on site precisions.  Let that be where precisions classes are held
    if X(50,:,i) == 0;
        X(50,:,i) = 1;
        X(49,:,i) = 0;
    end  
    
end

%% 
%policy sim 1.5: No voc offered in any schools or area schools
X(52,:,:) = 0; 
X(53,:,:) = 0; 
X(54,:,:) = 0;

X(47,:,:) = 0; 
X(48,:,:) = 0; 
X(49,:,:) = 0; 
X(50,:,:) = 0; 


%% 

%policy sim 2: free community college
%average cost of $3,300 - converted to hourly - $1.59 - log: .463734.  Then multiply by OP(7), the amount of utility 1 log dollar is worth
%Increase constant by this much, decrease SES variable by half
%This way no effect on rich (constant and SES cancel out), double effect on poorest (from -2 SES number they have)
P(13,69) = P(13,69)+.463734*OP(7);
P(13,33) = P(13,33)-.231867*OP(7);

%See bottom of file for how to simulate cost

%% 

%Policy sim 3: tracking (and voc concentration gives you a 1-yr trade degree)

%First set everyone's first two years of HS to gen ed if they attended high school or unknown (so only their last two years will matter for their curriculum)
for i = 1:N;
    if (ystar(i,1) >= 0 & ystar(i,1) <=5) | ystar(i,1) == 18
        ystar(i,1) = 2;
    end
    if (ystar(i,2) >= 0 & ystar(i,2) <=5) | ystar(i,2) == 18
        ystar(i,2) = 2;
    end
end  

%Those with testscores in the bottom 1/3 (below -.437) can only take vocational courses.  Those in the middle 1/3 can only take gen ed.  Those in the top third (above .478) can only take academic courses
[indLL12,indwageLL12,indLLutil12,wageLL12,indLLchoice12,emax212,dindLL12,dwageLL12,dutilLL12,LLnc0412,LLhs0012,demax212,choice12,sim1ystar12,indLchoice12,indLwage12] = PolSim_EE10_2typ_2lvlwexp_util_tracking(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim,norsim,nvattain); 
    
clear mex
%Use aggregation above to create Xpol and ystarsim (nothing about the experience aggregation has changed, only things in the fortran file



%% 

%Policy sim4:voc concentration (trade or bus) gives you a 1-yr trade degree as well
[indLL12,indwageLL12,indLLutil12,wageLL12,indLLchoice12,emax212,dindLL12,dwageLL12,dutilLL12,LLnc0412,LLhs0012,demax212,choice12,sim1ystar12,indLchoice12,indLwage12] = PolSim_EE10_2typ_2lvlwexp_util_VocpseinHS(X,Y,Z,P,ystar,w,esim,W,B,WW,XP,OP,NP,HP,evsim,wexpsim,norsim,nvattain); 
    
clear mex
% 
%% 

%For policy sims 3 and 4: you recieve a 1yr PSE degree when you graduate HS in the trade or bus fields below.  Thus you need to create outcome variables slightly differently after running the simulation.

%Run twice, for each type of unobserved heterogeneity type
 %ystarsim = transpose(indLwage12);
 ystarsim = transpose(indLchoice12);

 %Create information for years of each type of HS curricula
 Ypol = zeros(5,T,N);
 %Add initial conditions for students who were ahead in 00
 for i = 1:N;
    Ypol(2,1,i) = Y(2,1,i);
 end


        %Next, update the state space vector Ypol for period 2
for i = 1:N;
    for k = 1:T;       
        Ypol(:,k+1,i) = Ypol(:,k,i);

            if ystarsim(i,k) == 1;
                Ypol(1,k+1,i) = Ypol(1,k,i) + 1;
            end
            if ystarsim(i,k) == 2;
                Ypol(2,k+1,i) = Ypol(2,k,i) + 1;
            end
            if ystarsim(i,k) == 3;
                Ypol(3,k+1,i) = Ypol(3,k,i) + 1;
            end
            if ystarsim(i,k) == 4;
                Ypol(4,k+1,i) = Ypol(4,k,i) + 1;
            end
            if ystarsim(i,k) == 5;
                Ypol(5,k+1,i) = Ypol(5,k,i) + 1;
            end
     end
end

Xpol = zeros(9,T,N);
        %Finally, update the state space vector Xpol for period 2
for i = 1:N;
    for k = 1:T;       
        Xpol(:,k+1,i) = Xpol(:,k,i);

        %If you graduated from high school this year
        if Ypol(1,k+1,i) + Ypol(2,k+1,i) + Ypol(3,k+1,i) + Ypol(4,k+1,i) + Ypol(5,k+1,i) == 4
            if Ypol(1,k,i) + Ypol(2,k,i) + Ypol(3,k,i) + Ypol(4,k,i) + Ypol(5,k,i) == 3
                 
                %Trade voc no matter what
                   if Ypol(4,k,i) >= 2 && Ypol(3,k,i) == 0;
                        Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                   end

                %bus voc no matter what
                   if Ypol(3,k,i) >= 2 && Ypol(4,k,i) == 0;
                       Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                   end
                   
                %other voc no matter what
                   if Ypol(5,k,i) >= 2 && Ypol(4,k,i) == 0 && Ypol(3,k,i) == 0;
                       Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                   end
                   
                %Trade voc unless bus voc
                   if Ypol(4,k,i) >= 2 && Ypol(3,k,i) == 1;
                        if ystarsim(i,k) ~= 3;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;  
                        end
                   end
                  
                %Bus voc unless trade voc
                   if Ypol(3,k,i) >= 2 && Ypol(4,k,i) == 1;
                        if ystarsim(i,k) ~= 4;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless trade voc
                   if Ypol(5,k,i) >= 2 && Ypol(4,k,i) == 1;
                        if ystarsim(i,k) ~= 4;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;  
                        end
                   end
                   
                %Other voc unless bus voc
                   if Ypol(5,k,i) >= 2 && Ypol(3,k,i) == 1;
                        if ystarsim(i,k) ~= 3;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;  
                        end
                   end
                           
                %No more then one year of any voc/academic curricula (curicula is whatever you choose senior year)                                                            
                   if Ypol(3,k,i) <= 1 && Ypol(4,k,i) <=1 && Ypol(5,k,i) <= 1 && Ypol(1,k,i) <=1;
                        if ystarsim(i,k) == 1;
                            Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                        end
                        if ystarsim(i,k) == 2;
                            Xpol(2,k+1,i) = Xpol(2,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 5;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                   end
                                              
                 %Academic equal to 2 and all voc equal to 0 or 1 (implied)
                   if Ypol(1,k,i) == 2;
                        if ystarsim(i,k) >= 1 && ystarsim(i,k) <=2;
                            Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                        end
                        if ystarsim(i,k) == 3;
                            Xpol(3,k+1,i) = Xpol(3,k,i) + 1;
                        end
                        if ystarsim(i,k) == 4;
                            Xpol(4,k+1,i) = Xpol(4,k,i) + 1;
                        end
                        if ystarsim(i,k) == 5;
                            Xpol(5,k+1,i) = Xpol(5,k,i) + 1;
                        end
                   end
                   
                  %Academic equal to 3 (academic no matter what)
                   if Ypol(1,k,i) == 3;
                        Xpol(1,k+1,i) = Xpol(1,k,i) + 1;
                   end
                                          
            end
        end
        
        %GED completion
        if ystarsim(i,k) == 15
           Xpol(6,k+1,i) = Xpol(6,k,i) + 1; 
        end
        
     end
end 


%Create information for years of each type of college graduation
 Zpol = zeros(3,T,N);

        %Next, update the state space vector Ypol for period 2
for i = 1:N;
    for k = 1:T; 
        Zpol(:,k+1,i) = Zpol(:,k,i);

            if ystarsim(i,k) == 12;
                Zpol(1,k+1,i) = Zpol(1,k,i) + 1;
            end
            if ystarsim(i,k) == 13;
                Zpol(2,k+1,i) = Zpol(2,k,i) + 1;
            end
            if ystarsim(i,k) == 14;
                Zpol(3,k+1,i) = Zpol(3,k,i) + 1;
            end
     end
end

        %Finally, update the state space vector Xpol for period 2
for i = 1:N;
    for k = 1:T;       
        Xpol(7:9,k+1,i) = Xpol(7:9,k,i);
        %PSX(6:8,k+1,i) = PSX(6:8,k,i);
        
        %If you graduated from trade school this year
        if ystarsim(i,k) == 12;
             Xpol(7,k+1,i) = Xpol(7,k,i) + 1;
             %PSX(6,k+1,i) = PSX(6,k,i) + 1;
        end
        
        %If you graduated from trade or bus high school fields this year
        if Xpol(3,k,i) == 0 && Xpol(4,k,i) == 0;
            if Xpol(3,k+1,i) == 1 | Xpol(4,k+1,i) == 1;
                Zpol(1,k+1,i) = 1;
                Xpol(7,k+1,i) = 1;
            end
        end
        
             
        %If you graduated from community college this year
        if Zpol(2,k,i) == 1;
            if Zpol(2,k+1,i) == 2;
                 Xpol(8,k+1,i) = Xpol(8,k,i) + 1;
                 %PSX(7,k+1,i) = PSX(7,k,i) + 1;
            end
        end
                
        %If you graduated from university this year
        if Zpol(3,k,i) == 3;
            if Zpol(3,k+1,i) == 4;
                 Xpol(9,k+1,i) = Xpol(9,k,i) + 1;
                 %PSX(8,k+1,i) = PSX(8,k,i) + 1;
                                          
            end
        end
        
     end
end 


Xpolsim = Xpol(:,14,:);
Xpolsim = squeeze(Xpolsim);
Xpolsim = Xpolsim';
%have to copy: Xpolsim (education), ystarsim(13) (final choice), and wagesim(13) final wages


%Then: average wages
%average work choice final period
%Overall HS track choices
%Overall PSE attainment
%Same broken down by type?


%Easier to put in stata?
%Average wages
%avwagepol = mean(nonzero(wagesim(:,13)));

%% Simulate Free CC policy cost

%First, have to make all input variables 22 periods long
Xbig = cat(2,X,X(:,1:8,:));
Ybig = cat(2,Y,Y(:,1:8,:));
Zbig = cat(2,Z,Z(:,1:8,:));
ystarbig = cat(2,ystar,ystar(:,1:9));
wbig = cat(2,w,w(:,1:9));
WWbig = cat(2,WW,WW(:,1:8,:));
evsimbig = cat(3,evsim,evsim(:,:,1:9,:));
wexpsimbig = cat(1,wexpsim,wexpsim(1:9,:,:));
norsimbig = cat(3,norsim,norsim(:,:,1:9,:));

clear X evsim wexpsim norsim Y Z WW ystar w

[indLL12,indwageLL12,indLLutil12,wageLL12,indLLchoice12,emax212,dindLL12,dwageLL12,dutilLL12,LLnc0412,LLhs0012,demax212,choice12,sim1ystar12,indLchoice12,indLwage12] = PolSim_EE10_2typ_2lvlwexp_ttstarCC(Xbig,Ybig,Zbig,P,ystarbig,wbig,esim,W,B,WWbig,XP,OP,NP,HP,evsimbig,wexpsimbig,norsimbig,nvattain); 
    
clear mex

%% 

